library(testthat)
library(final)

test_check("final")
